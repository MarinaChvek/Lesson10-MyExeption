package com.homework.statelib;

public class MyE1 extends Exception {

    public MyE1(String message) {
        super(message);
    }
}
