package com.homework.statelib;

public class MyE4 extends MyE3 {
    public MyE4(String message) {
        super(message);
    }
}
