package com.homework.statelib;
import java.util.Scanner;
public class Main {

    public static void main(String[] args)
    {
        try
        {
            System.out.println("Введите число: ");
            Scanner scan = new Scanner(System.in);
            int number = scan.nextInt();
            method1(number);
            System.out.println("Введенное число: "+number);
        }
        catch ( MyE4 e)
        {
            System.out.println(e.getMessage());
        }
        catch ( MyE3 e)
        {
            System.out.println(e.getMessage());
        }
        catch ( MyE2 e)
        {
            System.out.println(e.getMessage());
        }
        catch ( MyE1 e)
        {
            System.out.println(e.getMessage());
        }

    }
    public static void method1(int i) throws MyE1, MyE2, MyE3, MyE4
    {

        if (i<10)
            throw new MyE1("Error is MyE1");
        if (i<20)
            throw new MyE2("Error is MyE2");
        if (i>1000)
            throw new MyE4("Error is MyE4");
        if (i>100)
            throw new MyE3("Error is MyE3");

    }


}
