package com.homework.statelib;

public class MyE3 extends MyE1 {
    public MyE3(String message) {
        super(message);
    }
}
