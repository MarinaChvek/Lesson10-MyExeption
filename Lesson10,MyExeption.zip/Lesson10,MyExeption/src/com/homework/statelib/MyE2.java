package com.homework.statelib;

public class MyE2 extends Exception {
    public MyE2(String message) {
        super(message);
    }
}
